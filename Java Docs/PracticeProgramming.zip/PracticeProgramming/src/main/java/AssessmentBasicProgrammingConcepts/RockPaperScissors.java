/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AssessmentBasicProgrammingConcepts;

import java.util.Scanner;

/**
 *
 * @author pisce
 */
public class RockPaperScissors {
    public static void main(String[] args) {
        
        //declare and initialize variables
                
        int rock = 1;
        int paper = 2;
        int scissors = 3; 
        
        int numRounds; 
        
        int scoreUser;
        int scoreComp;
        int scoreTie;
        
        String stringUserInput = "";
        String userInput = "";
                
        Scanner playGame = new Scanner(System.in);
        /*
        //Get user input
        System.out.println("Hi! Want to play rock, paper, scissors? (y/n)?");
        stringUserInput = playGame.nextLine();
        if(stringUserInput )
        
        
        
        */
        
        
        
    }
           
         
}
