/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.foundations.basics;

/**
 *
 * @author pisce
 */
public class ABeginning {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println("Hello from the Guild!");
        System.out.println("Typing code is easier than I thought...");
        System.out.println("Typity Typity Type!");
        System.out.println("After I finish typing,");
        System.out.println("And then when I run it,");
        System.out.println("The console will print out all my brilliant words!");
        System.out.println("And it all starts with 'Hello World!'..");
        
        
    }
}
