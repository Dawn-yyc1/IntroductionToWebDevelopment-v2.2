/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dawnc.practiceprogramming.variables;

/**
 *
 * @author pisce
 */
public class AllAboutMe {
    public static void main(String[] args) {
        
        String name = "Dawn";
        String food, pets, home, whistle;
        
        food = "chocolate";
        pets = "no pets, as I am allergic";
        home = "I live in a house.";
        whistle = "true I know how to whistle.";
        
        System.out.println("My name is " + name +".");
        System.out.println("My favorite food is " + food +".");
        System.out.println("I have " + pets +".");
        System.out.println(home);
        System.out.println("It is " + whistle);
        
        
        
    }
}
