/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dawnc.practiceprogramming.variables;

/**
 *
 * @author pisce
 */
public class InABucket {
    public static void main(String[] args) {
        
        //declaring variables
        String walrus;
        double piesEaten;
        float wieghtOfTeacupPig;
        int grainsOfSand;
        
        //putting date inside variable
        walrus = "Sir Leroy Jenkins III";
        piesEaten = 42.1;
        
        System.out.println("Meet my pet walrus, " + walrus);
        System.out.print("He was a bit hungry today, and ate this many pies : ");
        System.out.println(piesEaten);
    }
}
