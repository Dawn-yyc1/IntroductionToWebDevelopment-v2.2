/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dawnc.practiceprogramming.variables;

/**
 *
 * @author pisce
 */
public class TheOrderOfThings {
    public static void main(String[] args) {
        
        double number;
        String opinion, size, age, shape, color, origin, material, purpose;
        String noun;
        
        number = 5.0;
        opinion = "AWESOME";
        size = "teensy-weensy";
        age = "new";
        shape = "oblong";
        color = "yellow";
        origin = "Martian";
        material = "platinum";
        purpose = "good";
        
        noun = "dragons";
        
        // the " " print spaces between the words.
        
        //System.out.println(number + " " + opinion + " " + size + " " + age + " " + shape + " " + color + " " + origin + " " + material + " " + purpose + " " + noun);
        
       //comment out the code below and see what happens
        System.out.print(number);
        System.out.print(" " + opinion);
        System.out.print(" " + size);
        
        
        
        
        
        
        
        
    }
}
