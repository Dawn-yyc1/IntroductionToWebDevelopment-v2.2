/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dawnc.practiceprogramming.variables;

/**
 *
 * @author pisce
 */
public class BestAdderEver {
    public static void main(String[] args) {
        //variables
        int numOne;
        int numTwo;
        int numThree;
        int sum;
    
        //assign value to variables
        numOne = 4;
        numTwo = 20;
        numThree = 98;
        sum = numThree + numOne + numTwo;
             
        System.out.print("98 + 4 + 20" + " = ");
        System.out.print(sum);
        
                
    }
   
   
    
    
    
    
}
