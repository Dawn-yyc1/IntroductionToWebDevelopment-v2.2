/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dawnc.javamilestone2;

/**
 *
 * @author pisce
 */
public class SimpleCalculator {
    
    static double add(double num1, double num2){
        return num1 + num2;           
    }
    
    static double subtract(double num1, double num2){
        return num1 - num2;
    }
    
    static double divide (double num1, double num2){
        return num1/num2;
    }
    
    static double multiply(double num1, double num2){
        return num1 * num2;
    }
        
   // public double SimpleCalculator(int num1, int num2, String operator, double sum){
        
//        switch (operator) { 
//            case "+": sum = num1 + num2;
//            break;
//            case "-": sum = num1 - num2;
//            break;
//            case "/": sum = num1 / num2;
//            break;
//            case "*": sum = num1 * num2;
//            break;
//        }
//        System.out.println("The result of " + num1 + operator + num2 +" is " + sum);
//        return num1 + num2;
        
    
}
